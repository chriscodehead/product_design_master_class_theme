<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>success</title>
</head>

<body>
	<h2 style="margin:40px; background-color:#CB9C9D; padding:40px; box-shadow:0px 0px 1px 1px #666666;" align="center">
		Your password was successfully updated. 
		<a href="../login">LogIn</a>
	</h2>
</body>
</html>