<?php require_once('../library.php'); ?>
<?php
$cal->running_day();
?>