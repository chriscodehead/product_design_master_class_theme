<?php require_once('../library.php'); ?>
<?php 

		$cal->add_interest_weeklyLA();
		$cal->weekly_ConunterLA();

		$cal->add_interest_weeklyLB();
		$cal->weekly_ConunterLB();

		$cal->add_interest_weeklyLC();
		$cal->weekly_ConunterLC();

		$cal->add_interest_weeklyLD();
		$cal->weekly_ConunterLD();

		$cal->add_interest_weeklyLE();
		$cal->weekly_ConunterLE();
	
?>